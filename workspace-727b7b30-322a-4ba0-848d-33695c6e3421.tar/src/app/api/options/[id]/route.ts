import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { name, price, advantages, disadvantages } = body

    const option = await db.option.update({
      where: { id: params.id },
      data: {
        name,
        price: price !== undefined ? parseFloat(price) : undefined,
        advantages,
        disadvantages
      }
    })

    return NextResponse.json(option)
  } catch (error) {
    console.error('Error updating option:', error)
    return NextResponse.json(
      { error: 'Failed to update option' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.option.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ message: 'Option deleted successfully' })
  } catch (error) {
    console.error('Error deleting option:', error)
    return NextResponse.json(
      { error: 'Failed to delete option' },
      { status: 500 }
    )
  }
}