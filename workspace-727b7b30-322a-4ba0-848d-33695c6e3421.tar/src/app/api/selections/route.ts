import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET() {
  try {
    const selections = await db.selectionTitle.findMany({
      include: {
        options: true,
        finalChoice: {
          include: {
            option: true
          }
        }
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json(selections)
  } catch (error) {
    console.error('Error fetching selections:', error)
    return NextResponse.json(
      { error: 'Failed to fetch selections' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, description } = body

    if (!title) {
      return NextResponse.json(
        { error: 'Title is required' },
        { status: 400 }
      )
    }

    const selection = await db.selectionTitle.create({
      data: {
        title,
        description: description || null
      },
      include: {
        options: true,
        finalChoice: true
      }
    })

    return NextResponse.json(selection, { status: 201 })
  } catch (error) {
    console.error('Error creating selection:', error)
    return NextResponse.json(
      { error: 'Failed to create selection' },
      { status: 500 }
    )
  }
}