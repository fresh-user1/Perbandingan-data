import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { optionId, reason } = body

    if (!optionId) {
      return NextResponse.json(
        { error: 'Option ID is required' },
        { status: 400 }
      )
    }

    // Check if selection exists
    const selection = await db.selectionTitle.findUnique({
      where: { id: params.id }
    })

    if (!selection) {
      return NextResponse.json(
        { error: 'Selection not found' },
        { status: 404 }
      )
    }

    // Check if option exists and belongs to this selection
    const option = await db.option.findFirst({
      where: { 
        id: optionId,
        selectionId: params.id
      }
    })

    if (!option) {
      return NextResponse.json(
        { error: 'Option not found or does not belong to this selection' },
        { status: 404 }
      )
    }

    // Upsert final choice
    const finalChoice = await db.finalSelection.upsert({
      where: { selectionId: params.id },
      update: {
        optionId,
        reason: reason || null
      },
      create: {
        selectionId: params.id,
        optionId,
        reason: reason || null
      },
      include: {
        option: true
      }
    })

    return NextResponse.json(finalChoice)
  } catch (error) {
    console.error('Error setting final choice:', error)
    return NextResponse.json(
      { error: 'Failed to set final choice' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.finalSelection.delete({
      where: { selectionId: params.id }
    })

    return NextResponse.json({ message: 'Final choice removed successfully' })
  } catch (error) {
    console.error('Error removing final choice:', error)
    return NextResponse.json(
      { error: 'Failed to remove final choice' },
      { status: 500 }
    )
  }
}