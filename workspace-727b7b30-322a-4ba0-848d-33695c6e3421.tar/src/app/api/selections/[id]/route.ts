import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const selection = await db.selectionTitle.findUnique({
      where: { id: params.id },
      include: {
        options: true,
        finalChoice: {
          include: {
            option: true
          }
        }
      }
    })

    if (!selection) {
      return NextResponse.json(
        { error: 'Selection not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(selection)
  } catch (error) {
    console.error('Error fetching selection:', error)
    return NextResponse.json(
      { error: 'Failed to fetch selection' },
      { status: 500 }
    )
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { title, description } = body

    const selection = await db.selectionTitle.update({
      where: { id: params.id },
      data: {
        title,
        description: description || null
      },
      include: {
        options: true,
        finalChoice: true
      }
    })

    return NextResponse.json(selection)
  } catch (error) {
    console.error('Error updating selection:', error)
    return NextResponse.json(
      { error: 'Failed to update selection' },
      { status: 500 }
    )
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await db.selectionTitle.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ message: 'Selection deleted successfully' })
  } catch (error) {
    console.error('Error deleting selection:', error)
    return NextResponse.json(
      { error: 'Failed to delete selection' },
      { status: 500 }
    )
  }
}