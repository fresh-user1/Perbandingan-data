import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json()
    const { name, price, advantages, disadvantages } = body

    if (!name || price === undefined) {
      return NextResponse.json(
        { error: 'Name and price are required' },
        { status: 400 }
      )
    }

    // Check if selection exists
    const selection = await db.selectionTitle.findUnique({
      where: { id: params.id }
    })

    if (!selection) {
      return NextResponse.json(
        { error: 'Selection not found' },
        { status: 404 }
      )
    }

    const option = await db.option.create({
      data: {
        name,
        price: parseFloat(price),
        advantages: advantages || '',
        disadvantages: disadvantages || '',
        selectionId: params.id
      }
    })

    return NextResponse.json(option, { status: 201 })
  } catch (error) {
    console.error('Error creating option:', error)
    return NextResponse.json(
      { error: 'Failed to create option' },
      { status: 500 }
    )
  }
}